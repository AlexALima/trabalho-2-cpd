#include <stdio.h> /* fopen, fprintf, fscanf, stderr */
#include <stdlib.h> /* srand, malloc, free */
#include <time.h> /* time */
#include <string.h> /* memcpy */
#include <sys/time.h>   /* struct timeval, gettimeofday */

/**************/
/* CABECALHOS */
/**************/

#define NUM_FILES 50
#define INPUT_SIZE 100000
#define MERGED_OUTPUT_SIZE NUM_FILES*INPUT_SIZE

int totalCalls;

typedef struct{
    struct timeval start;
    struct timeval end;
} Timer;

void startTimer(Timer* t);
float stopTimer(Timer* t);

int* readFile(char* fileName);
void writeFile(char* fileName, int* C, int size);

void runMergeSort(int* array, int size);
void runQuickSort(int* array, int size);
int isArraySorted(int* array, int size);
void mergeSortedArrays(int** input, int* output);
void mergeWithSelectionTree(int** input, int* output);

int head_of_file[NUM_FILES]; // usado para indicar onde esta o proximo dado nao-lido de cada array

/*************/
/* PRINCIPAL */
/*************/

void ex1()
{
    int i;
    char fileName[20];
    Timer t;
    float time;

    /* Array de ponteiros para 'NUM_FILES' arrays de dados */
    int* input[NUM_FILES];

    /* ordena cada um dos arquivos de entrada */
    for(i=0;i<NUM_FILES;i++){

        /* Le arquivo de entrada e coloca os dados no array 'input[i]' */
        sprintf(fileName,"files/file%02d.txt",i);
        printf("ENTRADA: %s\n",fileName);
        input[i] = readFile(fileName);

        /* ordena array */

        startTimer(&t);

        /* DESCOMENTE UM DOS METODOS ABAIXO PARA ORDENAR O ARRAY */
        //runMergeSort(input[i],INPUT_SIZE);
        //runQuickSort(input[i],INPUT_SIZE);

        time = stopTimer(&t);
        printf("Time %f\n",time);

        /* checa se esta ordenado */
        printf("ordenado? ");
        if(isArraySorted(input[i],INPUT_SIZE)){
            printf("sim\n");

            /* salva arquivo de saida */
            sprintf(fileName,"sorted/file%02d.txt",i);
            printf("SAIDA: %s\n",fileName);
            writeFile(fileName,input[i],INPUT_SIZE);
        }else{
            printf("nao\n");
        }

        free(input[i]);
    }
}

void ex2()
{
    int i;
    char fileName[20];
    Timer t;
    float time;

    /* Array de ponteiros para 'NUM_FILES' arrays de dados */
    int* input[NUM_FILES];

    /* Le arquivos de entrada (ja ordenados) */
    for(i=0;i<NUM_FILES;i++){

        /* Le arquivo de entrada e coloca os dados no array 'input[i]' */
        sprintf(fileName,"sorted/file%02d.txt",i);
        printf("ENTRADA: %s\n",fileName);
        input[i] = readFile(fileName);
    }

    /* Aloca array de saida que ira conter todos os dados de entrada */
    int* output = (int*) malloc(MERGED_OUTPUT_SIZE*sizeof(int));

    /* Copia (concatena) dados de entrada no array de saida */
    for(i=0;i<NUM_FILES;i++){
        memcpy(&output[i*INPUT_SIZE],input[i],INPUT_SIZE*sizeof(int));
    }

    printf("ordenado? %s\n",(isArraySorted(output,MERGED_OUTPUT_SIZE)?"sim":"nao"));

    startTimer(&t);

    /* DESCOMENTE UM DOS METODOS ABAIXO PARA ORDENAR O ARRAY DE SAIDA */
//    runQuickSort(output,MERGED_OUTPUT_SIZE);
//    mergeSortedArrays(input,output,NUM_FILES,MERGED_OUTPUT_SIZE);
//    mergeWithSelectionTree(input,output,NUM_FILES,MERGED_OUTPUT_SIZE);

    time = stopTimer(&t);
    printf("Time %f\n",time);

    printf("ordenado? %s\n",(isArraySorted(output,MERGED_OUTPUT_SIZE)?"sim":"nao"));

    /* salva arquivo de saida */
    sprintf(fileName,"sorted/output.txt");
    printf("SAIDA: %s\n",fileName);
    writeFile(fileName,output,MERGED_OUTPUT_SIZE);
}

int main()
{
    srand(time(NULL));

    /* inicializa indicadores do inicio de cada array */
    for(int k=0;k<NUM_FILES;k++)
        head_of_file[k]=0;

    /* Exercicio 1 */
    ex1();

    /* Exercicio 2 */
//    ex2();

    return 0;
}

/*********************************/
/* Metodos usados no EXERCICIO 1 */
/*********************************/

int isArraySorted(int* array, int size)
{
    int i;
    for(i=0;i<size-1;i++){
        if(array[i]>array[i+1])
            return 0;
    }
    return 1;
}

void merge(int *C, int* Aux, int i, int m, int f)
{
    /*TODO: Implementar o metodo */


}

void mergeSort(int *C, int* Aux, int i, int f)
{
    totalCalls++;

    /*TODO: Implementar o metodo */


}

int partition(int* C, int pi, int pf)
{
    /*TODO: Implementar o metodo */


}

void quickSort(int* C, int i, int f)
{

    totalCalls++;

    /*TODO: Implementar o metodo */


}

void runMergeSort(int* array, int size)
{
    totalCalls=0;

    /* Aloca array auxiliar com o tamanho certo de elementos */
    int *Aux = (int*) malloc(size*sizeof(int));

    mergeSort(array,Aux,0,size-1);

    free(Aux);

    printf("Total calls %d\n",totalCalls);
}

void runQuickSort(int* array, int size)
{
    totalCalls=0;

    quickSort(array,0,size-1);

    printf("Total calls %d\n",totalCalls);

}

/*********************************/
/* Metodos usados no EXERCICIO 2 */
/*********************************/

int topFromArray(int** input, int k)
{
    if(head_of_file[k]<INPUT_SIZE)
        return input[k][head_of_file[k]];
    else
        return 10000000;
}

int popFromArray(int** input, int k)
{
    if(head_of_file[k]<INPUT_SIZE)
        return input[k][head_of_file[k]++];
    else
        return 10000000;
}

int popFromSelectionTree(int* tree, int** input, int p)
{
    int r;

    /*TODO: Implementar o metodo */


    return r;
}

void mergeWithSelectionTree(int** input, int* output, int p, int n)
{
    int size=2*p-1;
    int* tree = (int*) malloc(size*sizeof(int));

    /*TODO: Implementar o metodo */



}

void mergeSortedArrays(int** input, int* output, int p, int N)
{
    /*TODO: Implementar o metodo */



}


/********************/
/* Metodos do TIMER */
/********************/

void startTimer(Timer* t)
{
    gettimeofday(&(t->start), NULL);
}

float stopTimer(Timer *t)
{
    gettimeofday(&(t->end), NULL);

    if (t->start.tv_usec > t->end.tv_usec) {
        t->end.tv_usec += 1000000;
        t->end.tv_sec--;
    }

    return (float)(t->end.tv_sec - t->start.tv_sec) +
           ((float)t->end.tv_usec - (float)t->start.tv_usec)/1000000.0;
}

/*****************************/
/* Entrada e Saida - Arquivos*/
/*****************************/

int* readFile(char* fileName)
{
    /* Aloca array com o tamanho certo de elementos */
    int *C = (int*) malloc(INPUT_SIZE*sizeof(int));

    /* Abre arquivo */
    FILE* fp;
    fp = fopen(fileName, "r");
    if (fp == NULL) {
      fprintf(stderr, "Can't open input file '%s'!\n",fileName);
      return C;
    }

    /* Le arquivo */
    int i;
    for(i=0;i<INPUT_SIZE;i++){
        fscanf(fp, "%d", &(C[i]) );
    }

    fclose(fp);

    return C;
}

void writeFile(char* fileName, int* C, int size)
{
    /* Abre arquivo */
    FILE* fp;
    fp = fopen(fileName, "w");
    if (fp == NULL) {
      fprintf(stderr, "Can't open output file '%s'!\n",fileName);
      return;
    }

    /* Escreve arquivo */
    int i;
    for(i=0;i<size;i++){
        fprintf(fp, "%06d ", C[i]);
        if(i%20==19)
            fprintf(fp, "\n");
    }

    fclose(fp);
}
