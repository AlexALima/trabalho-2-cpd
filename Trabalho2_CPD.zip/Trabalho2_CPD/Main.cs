﻿using System; // Console

namespace Lab_2
{
    public class Lab_2
    {
        public const int NUM_FILES = 50;
        public const int INPUT_SIZE = 100000;
        public const int MERGED_OUTPUT_SIZE = NUM_FILES * INPUT_SIZE;

        static void Main()
        {
            /* --------------------------------- DESCOMENTE UM DOS MÉTODOS ABAIXO ---------------------------------- */

            //Ex_1 a1 = new Ex_1(); // Instancia objeto para acessar os métodos de Ex_1
            //a1.ex1();     /* Exercicio 1 */

            //Ex_2 a2 = new Ex_2(); // Instancia objeto para acessar os métodos de Ex_2 
            //a2.ex2();     /* Exercicio 2 */

            //RadixSort RX = new RadixSort();
            //RX.Radix_Sort();
            

            Console.WriteLine("\n..........................................................................");
            Console.ReadKey();
        }
    }
}

